<?php

if(isset($_post['btntest'])){}
    $host="localhost";
    $user="root";
    $pass="";
    $dbname="student";
$conn=mysqli_connect($host,$user, $pass, $dbname);
@$insert ="insert into col values ($Col_No,$Col_Name,$Dep_No)";
$sql="select S.St_No ,S.St_Name, C.Col_Name,D.Dep_Name from St S, Col C,depart D
Where S.Dep_No in (Select D.Dep_No From depart Where D.Col_No IN (SELECT C.Col_No From Col))";
$res= mysqli_query($conn,$sql);
//mysqli_query($conn,$res);
       
           
        
        if(isset($_POST['Col_No'])){
            $Col_No =$_POST['Col_No'];
                }
        if(isset($_POST['Col_Name'])){
            $Col_Name =$_POST['Col_Name'];
                }
$sqls='';
        if(isset($_POST['add'])){
            $sqls="INSERT INTO col VALUES ($Col_No,'$Col_Name')";
            mysqli_query($conn,$sqls);
            header("location:add.php");
                                 } 
            
           if(isset($_POST['del'])){
            $sqls="DELETE FROM col WHERE Col_Name='$Col_Name' ";
            mysqli_query($conn,$sqls);
            header("location:add.php");
                }
?>
<!Doctype HTML>

<html dir="rtl">
<head>
    
    <style>
         body{
	           background-color:darkgray;
	           margin:2;
	           font-family:Georgia, seri;
	           size:12px;	
             }
#tbl{   
                width: 100%;
                font-size: 25px;
                color: black;
                font-family: 'Segoe UI Light'; 
            }
        #tbl th{
               background-color:cadetblue;
               color:white;
               font-size: 40px 20px;
               text-align: center;
            }



</style>
    
    
    </head>

<body>





<form >
        <main>
          <table id="tbl">
            <tr>
             <th>رقم الطالب</th>
             <th>اسم الطالب</th>
             <th>اسم الكلية</th>
             <th>اسم القسم </th>
            </tr>
                  <?php
                      while( $row =mysqli_fetch_array($res)){
                         echo"<tr>";
                             echo"<td>".$row['St_No']."</td>";
                             echo"<td>".$row['St_Name']."</td>";
                             echo"<td>".$row['Col_Name']."</td>";
                             echo"<td>".$row['Dep_Name']."</td>";
                        echo"</tr>";               
                      }
                   ?>
         </table>
     </main>
   </form>
    <div class="bottom_pos">
              <a href="index.php" style="text-decoration: none;" ondragover=" "> العــــــودة </a>
          </div>
    </body>
</html>