<!Doctype HTML>
<html>
    <head>
        <style>
            body{
	background-color:darkgray;
	margin:0;
	font-family:Georgia, seri;
	size:12px;	
        }
           aside{
                text-align: center;
              padding: 22px;
               margin-top: 50px;
               align-content: center;
               
                
                border: 2px solid black;
                font-size: 25px;
                padding: 15px;
         background-color:cadetblue;
                
                
            }
        
        
        
        
        </style>
        
        <title> عن المشروع</title>
        
    </head>
    <body dir="rtl">
        
   <aside>
  			
				
                        
                        
                        <h1><strong>اسم المشروع: </strong>نظام ادارة الكليات</h1>
                        <h1><strong>بواسطة : </strong>محمد علي صالح الكليبي</h1>
                        <h1><strong>الكلية : </strong>كلية الحاسبات</h1>
                        <h1><strong>القســـم: </strong>علوم الحاسوب</h1>
                <h1><strong>مدرس المادة: </strong>علي العبال</h1>
                        
       </aside>
    </body>
</html>