<!DOCTYPE html>
<?php
$host = 'localhost';
$username = 'root';
$pass = '';
$db = 'student';

$db = new mysqli($host,$username,$pass,$db);

if ($db->connect_error) {
	 die("Connection Failed". $db->connect_error);
}

?>


<html>
<head>
  <title>ادارة الكليات</title>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" href="bootstrap.min.css">
     <script src="jquery.min.js"></script>
     <script src="bootstrap.min.js"></script>
 <style>
    
       body{
	          background-color:darkgray;
	          margin:0px;
	          font-family:Georgia, seri;
	          size:15px;	
            }
         aside{
                text-align: center;
                width:400px;
                margin: 100px;
                margin-left: 500px;
                border: 2px solid black;
                font-size: 25px;
                padding: 15px;
                background-color:cadetblue;
              }
        input{
                border: 2px solid black;
                text-align: center;
                font-size: 17px;
                font-family: sans-serif;
                margin-top:8px;
                background:#CECECE;
	            width:150px;
	            margin:0 auto;
 	            height:20px;
	            border-radius:2px;
	            box-shadow:#cda 3px 2px 2px 2px;
             }
           mother{
                 width: 100%;
                font-size: 50px;
                 }  
        .overlay {
                 height: 100%;
                 width: 0;
                 position: fixed;
                 z-index: 1;
                 top: 0;
                 left: 0;
                 background-color: rgb(0,0,0);
                 background-color: rgba(0,0,0, 0.9);
                 overflow-x: hidden;
                 transition: 0.5s;
                 }

.overlay-content {
                 position: relative;
                 top: 25%;
                 width: 100%;
                 text-align: center;
                 margin-top: 30px;
                 }

.overlay a {
                 padding: 8px;
                 text-decoration: none;
                 font-size: 36px;
                 color: #818181;
                 display: block;
                 transition: 0.1s;
}

.overlay a:hover, .overlay a:focus {
    color: #f1f1f1;
}

.closebtn {
    position: absolute;
    top: 20px;
    right: 45px;
    font-size: 60px !important;
}
   .form-control{
     
     background-color:darkgrey;
       text-align: center;
       border-top-style:groove;
       border-top-color: black;
       font-size: 19px;
       color: black;

     }
         
        
    </style>
</head>
<body>
    
<?php
  
  $query = "SELECT * FROM Col";
  $result = $db->query($query);
?>

        
 <div id="mother">
    <form method="POST">
      <aside dir="rtl">
        <div id="div">
         <img src="logo.png" width="200px"><br>
            <label for="email">الكلــــية</label>
              <select name="Col" id="Col" class="form-control" onchange="FetchDEP(this.value)" >
               <option value=""> الكلــــية</option>
                 <?php
                 if ($result->num_rows > 0 ) {
                  while ($row = $result->fetch_assoc()) {
                  echo '<option value='.$row['Col_No'].'>'.$row['Col_Name'].'</option>';
               }
            }
          ?> 
            </select>
        </div>
           <div class="form-group" >
              <label for="pwd">القـــــسم</label>
              <select name="DEP" id="DEP" class="form-control" onchange="FetchST(this.value)"  required>
              <option> القـــــسم</option>
              </select>
           </div>
         <div class="form-group">
            <label for="pwd">الطالب</label>
              <select name="ST" id="ST" class="form-control">
              <option> الطالب</option>
              </select>
         </div>
              <div id="myNav" class="overlay">
                 <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">رجوع</a>
                     <div class="overlay-content">
                       <a href="AboutManagement.php">عن المشروع </a>
                         <a href="add.php">اضافة طالب جديد</a>
                         <a href="tabal.php">اسماء الطلاب المسجلين </a>
                         <a href="#">العودة الي صفحة البداية</a>
                     </div>
                </div>
             </aside>
      </form > 
 </div>
        <span style="font-size:30px;cursor:pointer" onclick="openNav()">☰ مزيد من الخيارات</span>
                  <script>
                  function openNav() {
                   document.getElementById("myNav").style.width = "100%";
                  }

                 function closeNav() {
                  document.getElementById("myNav").style.width = "0%";
                   }
                </script>
     
         <script type="text/javascript">
           function FetchDEP(id){
           $('#DEP').html('');
            $('#ST').html('<option>Select ST</option>');
            $.ajax({
             type:'post',
              url: 'ajaxdata.php',
               data : { Col_id : id},
                success : function(data){
               $('#DEP').html(data);
                }
               })
             }
               function FetchST(id){ 
                $('#ST').html('');
                 $.ajax({
                  type:'post',
                   url: 'ajaxdata.php',
                   data : { DEP_id : id},
                   success : function(data){
                   $('#ST').html(data);
                   }
                 })
               }
             </script>
  </body>
</html>
