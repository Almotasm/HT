<?php

if(isset($_post['btntest'])){}
    $host="localhost";
    $user="root";
    $pass="";
    $dbname="student";
$conn=mysqli_connect($host,$user, $pass, $dbname);
@$insert ="insert into col values ($Col_No,$Col_Name,$Dep_No)";
$sql="select S.St_No ,S.St_Name, C.Col_Name,D.Dep_Name from St S, Col C,depart D
Where S.Dep_No in (Select D.Dep_No From depart Where D.Col_No IN (SELECT C.Col_No From Col))";
$res= mysqli_query($conn,$sql);
//mysqli_query($conn,$res);
       
           
        
        if(isset($_POST['Col_No'])){
            $Col_No =$_POST['Col_No'];
                }
        if(isset($_POST['Col_Name'])){
            $Col_Name =$_POST['Col_Name'];
                }
$sqls='';
        if(isset($_POST['add'])){
            $sqls="INSERT INTO col VALUES ($Col_No,'$Col_Name')";
            mysqli_query($conn,$sqls);
            header("location:add.php");
                                 } 
            
           if(isset($_POST['del'])){
            $sqls="DELETE FROM col WHERE Col_Name='$Col_Name' ";
            mysqli_query($conn,$sqls);
            header("location:add.php");
                }
?>
<!DOCTYPE html>
<html dir="rtl">
    <head>
    <style>
        input{
                border: 2px solid black;
                text-align: center;
                font-size: 17px;
                font-family: sans-serif;
                margin-top:8px;
                background:#CECECE;
	            width:150px;
	            margin:2 auto;
	            height:20px;
	            border-radius:2px;
	            box-shadow:#cda 3px 2px 2px 2px;
                line-height: normal;
             }
        button{
            padding: 10px 10px;
            background-color:blanchedalmond;
            color: black;
            font-size: 20px;
            outline-color: firebrick;
            box-shadow: 7px;
         }
        aside{
                text-align: center;
                width: 400px;
                float:right;
                border: 1px solid black;
                font-size: 20px;
                padding: 10px;
                background-color:cadetblue;   
            }
        body{
	           background-color:darkgray;
	           margin:2;
	           font-family:Georgia, seri;
	           size:12px;	
             }
        #tbl{   
                width: 910px;
                font-size: 22px;
                color: black;
                font-family: 'Segoe UI Light'; 
            }
        #tbl th{
               background-color:cadetblue;
               color:white;
               font-size: 30px 15px;
               text-align: center;
            }
        mother.script{
                width: 100%;
                font-size: 30px;
        }
        body {
              margin: 0;
              font-family: 'Lato', sans-serif;
              }
       .overlay {
              height: 100%;
              width: 0;
              position: fixed;
              z-index: 1;
              top: 0;
              left: 0;
              background-color: rgb(0,0,0);
              background-color: rgba(0,0,0, 0.9);
              overflow-x: hidden;
              transition: 0.5s;
                }
       .overlay-content {
             position: relative;
             top: 25%;
             width: 100%;
             text-align: center;
             margin-top: 30px;
             }
       .overlay a {
             padding: 8px;
             text-decoration: none;
             font-size: 36px;
             color: #818181;
             display: block;
             transition: 0.3s;
}
       .overlay a:hover, .overlay a:focus {
              color: #f1f1f1;
}
       .closebtn {
              position: absolute;
              top: 20px;
              right: 45px;
              font-size: 60px !important;
}

@media screen and (max-height: 450px) {
  .overlay a {font-size: 20px}
  .closebtn {
    font-size: 40px !important;
    top: 15px;
    right: 35px;
  }
}
        </style>
</head>
    <body>
      <script>
function openNav() {
    document.getElementById("myNav").style.width = "100%";
}

function closeNav() {
    document.getElementById("myNav").style.width = "0%";
}
</script>
      <div id="myNav" class="overlay">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
  <div class="overlay-content">
    <a href="#">About</a>
    <a href="#">Services</a>
    <a href="#">Clients</a>
    <a href="#">Contact</a>
  </div>
</div>
    <div id="mother">
        <form method="POST" id="form1" action="add.php">
            <aside>
                <div id="div">
                     <img src="logo.png" width="200px" alt="صورة الموقع">
                        <h3>اضــــافة طالب جديد</h3>
                        <label> الرقم التسلسلي</label><br>
                        <input type="text" name="Col_No" id="Col_No"     required  ><br><br>
                        <label>اسم الكلية</label><br>
                        <input type="text" name="Col_Name" id="Col_Name"  required><br><br>
                        <button name="add" autofocus >اضافة</button>
                    
                        <button name="del" autofocus formnovalidate>حذف</button> 
               </div>
          <div class="bottom_pos">
              <a href="index.php" style="text-decoration: none;" ondragover=" "> العــــــودة </a>
          </div>
           </aside>
        </form>
      </div>
 <div>
    <form >
        <main>
          <table id="tbl">
            <tr>
             <th>رقم الطالب</th>
             <th>اسم الطالب</th>
             <th>اسم الكلية</th>
             <th>اسم القسم </th>
            </tr>
                  <?php
                      while( $row =mysqli_fetch_array($res)){
                         echo"<tr>";
                             echo"<td>".$row['St_No']."</td>";
                             echo"<td>".$row['St_Name']."</td>";
                             echo"<td>".$row['Col_Name']."</td>";
                             echo"<td>".$row['Dep_Name']."</td>";
                        echo"</tr>";               
                      }
                   ?>
         </table>
     </main>
   </form>
 </div>
      <div id="myNav" class="overlay">
                 <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
                     <div class="overlay-content">
                       <a href="AboutManagement.php">عن المشروع </a>
                         <a href="add.php">اضافة طالب جديد</a>
                         <a href="#">اسماء الطلاب المسجلين </a>
                         <a href="index.php">العودة الي صفحة البداية</a>
                     </div>
                  </div>
</body>
</html>