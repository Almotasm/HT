<?php 
include_once 'config.php';

if (isset($_POST['Col_id'])) {
	$query = "SELECT * FROM depart where Col_No=".$_POST['Col_id'];
	$result = $db->query($query);
	if ($result->num_rows > 0 ) {
			echo '<option value="">القسم</option>';
		 while ($row = $result->fetch_assoc()) {
		 	echo '<option value='.$row['Dep_No'].'>'.$row['Dep_Name'].'</option>';
		 }
	}
    else
    {

		echo '<option>No DEP Found!</option>';
	}

     }
        elseif (isset($_POST['DEP_id'])) {
	 

	$query = "SELECT * FROM St where Dep_No=".$_POST['DEP_id'];
	$result = $db->query($query);
	if ($result->num_rows > 0 ) {
			echo '<option value="">الطــــــــالب</option>';
		 while ($row = $result->fetch_assoc()) {
		 	echo '<option value='.$row['St_No'].'>'.$row['St_Name'].'</option>';
		 }
	}
            else{

		echo '<option>No ST Found!</option>';
	}

}


?>